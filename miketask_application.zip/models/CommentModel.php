<?php

/**
* CommentModel
**/
class CommentModel extends Model
{
	// id
	public $type = "";
	public $parent = 0;
	public $text = "";
	public $user = 0;
	public $date = null;
	
	/**
	* Contstructor.
	* @param entry An id or array to initialize with.
	**/
	public function CommentModel($entry = null)
	{
		parent::init("comment", $entry);
	}
	
	/**
	* Gets a link to the comment.
	* @return string
	**/
	public function getLink()
	{
		$view = Zend_Layout::getMvcInstance()->getView();
		
		switch($this->type)
		{
			case "project":
				$project = new ProjectModel($this->parent);
				return $view->url(array('id'=>$project->link),"project",true) . "#comment_{$this->id}";
			
			case "task":
				return $view->url(array('id'=>$this->parent),"task",true) . "#comment_{$this->id}";
			
			case "user":
				return $view->url(array('id'=>$this->parent),"user",true) . "#comment_{$this->id}";
		}
	}
	
	// OVERWRITTEN FROM MODEL
	
	public function save()
	{
		if(empty($this->date))
			$this->date = null;
		parent::save();
	}
	
	public function validate()
	{
		$errors = array();
		
		if(empty($this->type))
			$errors['type'] = "Cannot be empty";
		if(empty($this->parent))
			$errors['parent'] = "Cannot be empty";
		if(empty($this->text))
			$errors['text'] = "Cannot be empty";
		
		return $errors;
	}
}
