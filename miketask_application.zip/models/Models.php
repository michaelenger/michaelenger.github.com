<?php

// Include all models here.
require_once APPLICATION_PATH . "/models/Model.php";
require_once APPLICATION_PATH . "/models/CommentModel.php";
require_once APPLICATION_PATH . "/models/FeedModel.php";
require_once APPLICATION_PATH . "/models/ProjectModel.php";
require_once APPLICATION_PATH . "/models/ResourceModel.php";
require_once APPLICATION_PATH . "/models/TaskModel.php";
require_once APPLICATION_PATH . "/models/UserModel.php";

/**
* Models
* Handles the fetching of all models from the database.
**/
class Models
{
	/**
	* Gets all comments.
	* @return array
	**/
	public static function getComments()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM comment ORDER BY id ASC");
		$comments = array();
		foreach($result as $entry)
			$comments[$entry['id']] = new CommentModel($entry);
		return $comments;
	}
	
	/**
	* Gets all feed items.
	* @param limit The amount to get (default: 20).
	* @return array
	**/
	public static function getFeed($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "id";
		if(!$order) $order = "DESC";
		
		// Build SQL
		$sql = "SELECT * FROM feed ORDER BY {$sort} {$order}";
		if($limit) $sql .= " LIMIT {$limit}";
		
		// Get feed items
		$result = $db->fetchAll($sql);
		$feed = array();
		foreach($result as $entry)
			$feed[$entry['id']] = new FeedModel($entry);
		return $feed;
	}
	
	/**
	* Gets a project based on the id or link.
	* @param project The id or link.
	* @return ProjectModel
	**/
	public static function getProject($project)
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchRow("SELECT * FROM project WHERE link = '{$project}' OR id = '{$project}'");
		if($result)
			return new ProjectModel($result);
		else
			return null;
	}
	
	/**
	* Gets a list of all projects.
	* @return array
	**/
	public static function getProjects()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM project ORDER BY name ASC");
		$projects = array();
		foreach($result as $entry)
			$projects[$entry['id']] = new ProjectModel($entry);
		return $projects;
	}
	
	/**
	* Gets a list of all resources.
	* @return array
	**/
	public static function getResources()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM resource ORDER BY id ASC");
		$resources = array();
		foreach($result as $entry)
			$resources[$entry['id']] = new ResourceModel($entry);
		return $resources;
	}
	
	/**
	* Gets a list of all tasks.
	* @return array
	**/
	public static function getTasks($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "date_completed ASC, priority DESC, id";
		if(!$order) $order = "ASC";
		if($type) $type = " AND task.type = '{$type}' ";
		
		// Build SQL
		if($sort == "hours")
			$sql = "
				SELECT task.*, SUM(task_timelog.amount) AS total FROM task, task_timelog
				WHERE task.id = task_timelog.task
				AND EXISTS (SELECT * FROM project WHERE project.id = task.project AND project.archived = 0)
				GROUP BY task_timelog.task
				UNION
				SELECT task.*, 0 AS total FROM task
				WHERE NOT EXISTS (SELECT * FROM task_timelog WHERE task_timelog.task = task.id)
				ORDER BY total {$order}
			";
		else
			$sql = "
				SELECT * FROM task
				WHERE EXISTS (SELECT * FROM project WHERE project.id = task.project AND project.archived = 0)
				ORDER BY {$sort} {$order}
			";
		if($limit) $sql .= " LIMIT {$limit}";
		
		// Get tasks
		$result = $db->fetchAll($sql);
		$tasks = array();
		foreach($result as $entry)
			$tasks[$entry['id']] = new TaskModel($entry);
		return $tasks;
	}
	
	/**
	* Gets a timelog entry.
	* @return array
	**/
	public static function getTimelog($id)
	{
		$db = Zend_Registry::getInstance()->database;
		return $db->fetchRow("SELECT * FROM task_timelog WHERE id = '{$id}'");
	}
	
	/**
	* Gets a user by email.
	* @param email The email to search for.
	* @return UserModel
	**/
	public static function getUserByEmail($email)
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchRow("SELECT * FROM user WHERE email = '{$email}'");
		if($result)
			return new UserModel($result);
		else
			return null;
	}
	
	/**
	* Gets a list of all users.
	* @return array
	**/
	public static function getUsers()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM user ORDER BY name ASC");
		$users = array();
		foreach($result as $entry)
			$users[$entry['id']] = new UserModel($entry);
		return $users;
	}
	
	/**
	* Remove a specific timelog entry.
	**/
	public static function removeTimelog($id)
	{
		$db = Zend_Registry::getInstance()->database;
		$db->delete("task_timelog", "id = '{$id}'");
	}
}
