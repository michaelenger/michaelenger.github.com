<?php

/**
* ResourceModel
**/
class ResourceModel extends Model
{
	// id
	public $project = 0;
	public $type = "";
	public $content = "";
	public $description = null;
	public $user = 0;
	public $date = null;
	
	/**
	* Contstructor.
	* @param entry An id or array to initialize with.
	**/
	public function ResourceModel($entry = null)
	{
		parent::init("resource", $entry);
	}
	
	/**
	* Gets the full description.
	* @return string
	**/
	public function getDescription()
	{
		if($this->type == "link")
			return (!empty($this->description) ? "{$this->description}: " : "") . $this->content;
		return
			$this->description;
	}
	
	/**
	* Gets the file type (if available).
	* @return string
	**/
	public function getFileType()
	{
		if($this->type != "file")
			return null;
		
		$ext = strtolower(substr($this->content, strrpos($this->content, ".") + 1));
		
		switch($ext)
		{
			case "mp3":
			case "mp4":
			case "aac":
			case "wav":
			case "wma":
				return "audio";
			
			case "exe":
				return "executable";
			
			case "bmp":
			case "jpeg":
			case "jpg":
			case "png":
				return "image";
			
			case "7z":
			case "gzip":
			case "rar":
			case "tar":
			case "zip":
				return "package";
			
			case "txt":
				return "text";
			
			case "avi":
			case "mpg":
			case "mpeg":
			case "wmv":
				return "video";
			
			default:
				return "unknown";
		}
	}
	
	/**
	* Gets an image (if available).
	* @return string
	**/
	public function getImage()
	{
		if($this->type == "file" && $this->getFileType() == "image")
			return $this->getLink();
		else
			return null;
	}
	
	/**
	* Gets a link to the resource.
	* @return string
	**/
	public function getLink()
	{
		$view = Zend_Layout::getMvcInstance()->getView();
		
		switch($this->type)
		{
			case "file":
				return $view->basepath . "resource/" . rawurlencode($this->content);
			
			case "link":
				return $this->content;
		}
		
		return null;
	}
	
	/**
	* Gets the descriptive type.
	* @return string
	**/
	public function getType()
	{
		if($this->type == "file")
			return $this->getFileType();
		return
			$this->type;
	}
	
	// OVERWRITTEN FROM MODEL
	
	public function delete()
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Delete file
		if($this->type == "file")
			unlink("resource/{$this->content}");
		
		// Delete all feed items
		$db->delete("feed", "type = 'resource' AND content = '{$this->id}'");
		
		// Delete
		parent::delete();
	}
	
	public function save()
	{
		if(empty($this->description))
			$this->description = null;
		if(empty($this->date))
			$this->date = null;
		parent::save();
	}
	
	public function validate()
	{
		$errors = array();
		
		if(empty($this->content))
			$errors['content'] = "Cannot be empty";
		elseif($this->type == "link" && stripos($this->content, "http://") !== 0)
			$this->content = "http://{$this->content}";
		
		return $errors;
	}
}
