<?php

/**
* UserModel
**/
class UserModel extends Model
{
	// id
	public $email = "";
	public $password = "";
	public $name = "";
	public $avatar = null;
	public $date_created = null;
	public $parent = 0;
	
	/**
	* Contstructor.
	* @param entry An id or array to initialize with.
	**/
	public function UserModel($entry = null)
	{
		parent::init("user", $entry);
	}
	
	/**
	* Gets the comments associated with this user.
	* @return array
	**/
	public function getComments()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM comment WHERE type = 'user' AND parent = '{$this->id}' ORDER BY id ASC");
		$comments = array();
		foreach($result as $entry)
			$comments[$entry['id']] = new CommentModel($entry);
		return $comments;
	}
	
	/**
	* Gets a list of the tasks completed by the user.
	* @return array
	**/
	public function getCompletedTasks()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchAll("
			SELECT * FROM task
			WHERE completed_by = '{$this->id}'
			AND EXISTS (SELECT * FROM project WHERE project.id = task.project AND project.archived = 0)
			ORDER BY date_completed ASC, priority DESC, id ASC
		");
		
		$tasks = array();
		foreach($result as $entry)
			$tasks[$entry['id']] = new TaskModel($entry);
		return $tasks;
	}
	
	/**
	* Gets the feed items associated with this user.
	* @return array
	**/
	public function getFeed($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "id";
		if(!$order) $order = "DESC";
		
		// Build SQL
		$sql = "
			SELECT * FROM feed
			WHERE user = '{$this->id}'
			OR (type = 'assign' AND content = '{$this->id}')
			OR (type = 'user' AND content = '{$this->id}')
			ORDER BY {$sort} {$order}
		";
		if($limit)
			$sql .= " LIMIT {$limit}";
		
		// Get feed
		$result = $db->fetchAll($sql);
		$feed = array();
		foreach($result as $entry)
			$feed[$entry['id']] = new FeedModel($entry);
		return $feed;
	}
	
	/**
	* Gets the total amount of hours spent by this user.
	* @return number
	**/
	public function getHours()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchRow("
			SELECT SUM(amount) AS hours FROM task_timelog
			WHERE user = '{$this->id}'
		");
		
		if($result['hours'])
			return $result['hours'];
		else
			return 0;
	}
	
	/**
	* Gets a list of the projects associated with this user.
	* @return array
	**/
	public function getProjects()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchAll("
			SELECT project.* FROM project,project_admin
			WHERE project.id = project_admin.project
			AND project_admin.user = '{$this->id}'
			ORDER BY project.name
		");
		
		$projects = array();
		foreach($result as $entry)
			$projects[$entry['id']] = new ProjectModel($entry);
		return $projects;
	}
	
	/**
	* Gets a list of the tasks associated with this user.
	* @return array
	**/
	public function getTasks($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "date_completed ASC, priority DESC, id";
		if(!$order) $order = "ASC";
		
		// Build SQL
		if($sort == "hours")
			$sql = "
				SELECT task.*, SUM(task_timelog.amount) AS total FROM task, task_timelog, task_assignment
				WHERE task.id = task_timelog.task
				AND task.id = task_assignment.task
				AND task_assignment.user = '{$this->id}'
				AND EXISTS (SELECT * FROM project WHERE project.id = task.project AND project.archived = 0)
				GROUP BY task_timelog.task
				UNION
				SELECT task.*, 0 AS total FROM task, task_assignment
				WHERE NOT EXISTS (SELECT * FROM task_timelog WHERE task_timelog.task = task.id)
				AND task.id = task_assignment.task
				AND task_assignment.user = '{$this->id}'
				ORDER BY total {$order}
			";
		else
			$sql = "
				SELECT task.* FROM task,task_assignment
				WHERE task.id = task_assignment.task
				AND task_assignment.user = '{$this->id}'
				AND EXISTS (SELECT * FROM project WHERE project.id = task.project AND project.archived = 0)
				ORDER BY {$sort} {$order}
			";
		if($limit) $sql .= " LIMIT {$limit}";
		
		// Get tasks
		$result = $db->fetchAll($sql);		
		$tasks = array();
		foreach($result as $entry)
			$tasks[$entry['id']] = new TaskModel($entry);
		return $tasks;
	}

	/**
	* Gets the list of timelogs.
	* @return array
	**/
	public function getTimelog($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;

		// Default values
		if(!$sort) $sort = "date";
		if(!$order) $order = "DESC";

		// Build SQL
		$sql = "
			SELECT * FROM task_timelog
			WHERE user = '{$this->id}'
			ORDER BY {$sort} {$order}
		";
		if($limit) $sql .= " LIMIT {$limit}";

		// Get timelog
		$result = $db->fetchAll($sql);

		return $result;
	}
	
	/**
	* Checks if the user is assigned the task.
	* @param task A TaskModel or id.
	* @return boolean
	**/
	public function hasAssignment($task)
	{
		if(is_object($task)) $task = $task->id;
		$db = Zend_Registry::getInstance()->database;
		return $db->fetchRow("SELECT * FROM task_assignment WHERE user = '{$this->id}' AND task = '{$task}'") || false;
	}
	
	/**
	* Checks if the user is member of a project.
	* @param user A ProjectModel or id.
	* @return boolean
	**/
	public function hasProject($project)
	{
		if(!is_object($project)) $project = new ProjectModel($project);
		return $project->hasMember($this->id);
	}
	
	/**
	* Attempts to fetch a user from the email and password.
	* @return boolean
	**/
	public function login()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchRow("SELECT * FROM user WHERE email = '{$this->email}' AND password = '".sha1($this->password)."'");
		if($result)
		{
			$this->fromArray($result);
			return true;
		}
		else
			return false;
	}
	
	// OVERWRITTEN FROM MODEL
	
	public function save()
	{
		if(empty($this->date_created))
			$this->date_created = null;
		parent::save();
	}
	
	public function validate()
	{
		$errors = array();
		
		if(empty($this->email))
			$errors['email'] = "Cannot be empty";
		if(empty($this->password))
			$errors['password'] = "Cannot be empty";
		if(empty($this->name))
			$errors['name'] = "Cannot be empty";
		
		return $errors;
	}
}
