<?php

/**
* ProjectModel
**/
class ProjectModel extends Model
{
	// id
	public $name = "";
	public $description = "";
	public $client = null;
	public $website = null;
	public $logo = null;
	public $link = "";
	public $creator = 0;
	public $date_created = null;
	public $archived = 0;
	
	/**
	* Contstructor.
	* @param entry An id or array to initialize with.
	**/
	public function ProjectModel($entry = null)
	{
		parent::init("project", $entry);
	}
	
	/**
	* Adds a user to the project.
	* @param user A UserModel or id.
	**/
	public function addUser($user)
	{
		$db = Zend_Registry::getInstance()->database;
		$view = Zend_Layout::getMvcInstance()->getView();
		if(is_object($user)) $user = $user->id;
		
		$array = array(
			'project' => $this->id,
			'user' => $user
		);
		
		$db->insert("project_admin", $array);
	}
	
	/**
	* Gets the comments associated with this project.
	* @return array
	**/
	public function getComments()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM comment WHERE type = 'project' AND parent = '{$this->id}' ORDER BY id ASC");
		$comments = array();
		foreach($result as $entry)
			$comments[$entry['id']] = new CommentModel($entry);
		return $comments;
	}
	
	/**
	* Gets the amount of tasks that are completed.
	* @return number
	**/
	public function getCompletedTasks()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchRow("
			SELECT count(*) AS count FROM task
			WHERE project = '{$this->id}'
			AND date_completed IS NOT NULL
		");
		return intval($result['count']);
	}
	
	/**
	* Gets the feed items associated with this project.
	* @param limit The amount to get (default: all).
	* @return array
	**/
	public function getFeed($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "id";
		if(!$order) $order = "DESC";
		
		// Build SQL
		$sql = "SELECT * FROM feed WHERE project = '{$this->id}' ORDER BY {$sort} {$order}";
		if($limit) $sql .= " LIMIT {$limit}";
		
		// Get feed
		$result = $db->fetchAll($sql);
		$feed = array();
		foreach($result as $entry)
			$feed[$entry['id']] = new FeedModel($entry);
		return $feed;
	}
	
	/**
	* Gets the percentage amount of progress.
	* @return number
	**/
	public function getProgress()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchRow("
			SELECT
				count(*) * 100.0 / (SELECT count(*) FROM task WHERE project = '{$this->id}')
				AS percentage
			FROM task
			WHERE project = '{$this->id}'
			AND date_completed IS NOT NULL
		");
		return intval($result['percentage']);
	}
	
	/**
	* Gets the resources associated with this project.
	* @return array
	**/
	public function getResources()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchAll("
			SELECT * FROM resource
			WHERE project = '{$this->id}'
			ORDER BY id ASC
		");
		
		$resources = array();
		foreach($result as $entry)
			$resources[$entry['id']] = new ResourceModel($entry);
		return $resources;
	}
	
	/**
	* Gets the tasks associated with this project.
	* @return array
	**/
	public function getTasks($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "date_completed ASC, priority DESC, id";
		if(!$order) $order = "ASC";
		
		// Build SQL
		if($sort == "hours")
			$sql = "
				SELECT task.*, SUM(task_timelog.amount) AS total FROM task, task_timelog
				WHERE task.id = task_timelog.task
				AND project = '{$this->id}'
				GROUP BY task_timelog.task
				UNION
				SELECT task.*, 0 AS total FROM task
				WHERE NOT EXISTS (SELECT * FROM task_timelog WHERE task_timelog.task = task.id)
				AND project = '{$this->id}'
				ORDER BY total {$order}
			";
		else
			$sql = "SELECT * FROM task WHERE project = '{$this->id}' ORDER BY {$sort} {$order}";
		if($limit) $sql .= " LIMIT {$limit}";
		
		// Get tasks
		$result = $db->fetchAll($sql);
		$tasks = array();
		foreach($result as $entry)
			$tasks[$entry['id']] = new TaskModel($entry);
		return $tasks;
	}
	
	/**
	* Gets the list of timelogs.
	* @return array
	**/
	public function getTimelog($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;

		// Default values
		if(!$sort) $sort = "id";
		if(!$order) $order = "ASC";

		// Build SQL
		$sql = "
			SELECT task_timelog.* FROM task_timelog, task
			WHERE task_timelog.task = task.id
			AND task.project = '{$this->id}'
			ORDER BY {$sort} {$order}
		";
		if($limit) $sql .= " LIMIT {$limit}";

		// Get timelog
		$result = $db->fetchAll($sql);

		return $result;
	}
	
	/**
	* Gets the users associated with this project.
	* @return array
	**/
	public function getUsers()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchAll("
			SELECT user.* FROM user,project_admin
			WHERE user.id = project_admin.user
			AND project_admin.project = '{$this->id}'
			ORDER BY user.name
		");
		
		$users = array();
		foreach($result as $entry)
			$users[$entry['id']] = new UserModel($entry);
		return $users;
	}
	
	/**
	* Checks if the project has the specified member.
	* @param user A UserModel or id.
	* @return boolean
	**/
	public function hasMember($user)
	{
		if(is_object($user)) $user = $user->id;
		return array_key_exists($user, $this->getUsers());
	}
	
	/**
	* Removes a specified resource from the project.
	* @param resource A ResourceModel or id.
	**/
	public function removeResource($resource)
	{
		if(!is_object($resource)) $resource = new ResourceModel($resource);
		$resource->delete();
	}
	
	/**
	* Removes a specified task from the project.
	* @param task A TaskModel or id.
	**/
	public function removeTask($task)
	{
		if(!is_object($task)) $task = new TaskModel($task);
		$task->delete();
	}
	
	/**
	* Remove a user from the project.
	* @param user A UserModel or id.
	**/
	public function removeUser($user)
	{
		$db = Zend_Registry::getInstance()->database;
		$view = Zend_Layout::getMvcInstance()->getView();
		if(is_object($user)) $user = $user->id;
		
		$db->delete("project_admin", "project = {$this->id} AND user = {$user}");
	}
	
	// OVERWRITTEN FROM MODEL
	
	public function delete()
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Delete all feed items associated with this project
		$db->delete("feed", "project = '{$this->id}'");
		
		// Delete all admin settings
		$db->delete("project_admin", "project = '{$this->id}'");
		
		// Delete the logo
		if(!empty($this->logo)) unlink("logo/{$this->logo}");
		
		// Delete the tasks
		foreach ($this->getTasks() as $task)
		{
			$task->delete();
		}
		
		// Delete
		parent::delete();
	}
	
	public function getLink()
	{
		if(!empty($this->link))
			return $this->link;
		else
			return $this->id;
	}
	
	public function save()
	{
		if(empty($client))
			$client = null;
		if(empty($website))
			$website = null;
		if(empty($this->date_created))
			$this->date_created = null;
		parent::save();
	}
	
	public function validate()
	{
		$errors = array();
		
		if(empty($this->name))
			$errors['name'] = "Cannot be empty";
		if(empty($this->description))
			$errors['description'] = "Cannot be empty";
		if(empty($this->link))
			$errors['link'] = "Cannot be empty";
		
		return $errors;
	}
}
