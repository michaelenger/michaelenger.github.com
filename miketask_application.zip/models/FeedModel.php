<?php

/**
* FeedModel
**/
class FeedModel extends Model
{
	// id
	public $type = "";
	public $project = null;
	public $task = null;
	public $content = null;
	public $date = null;
	public $user = 0;
	
	/**
	* Contstructor.
	* @param entry An id or array to initialize with.
	**/
	public function FeedModel($entry = null)
	{
		parent::init("feed", $entry);
	}
	
	/**
	* Gets the content of the feed.
	* @return string
	**/
	public function getContent()
	{
		$view = Zend_Layout::getMvcInstance()->getView();
		
		$user = new UserModel($this->user);
		$userlink = '<a class="user" href="'.$view->url(array('id'=>$user->id),"user",true).'">'.htmlspecialchars($user->name).'</a>';
		
		switch($this->type)
		{
			case "abandon": // user abandoned task
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				return "{$userlink} abandoned a task: {$tasklink}";
			
			case "assign": // user assigned a task
				$other = new UserModel($this->content);
				$otherlink = '<a class="user" href="'.$view->url(array('id'=>$other->id),"user",true).'">'.htmlspecialchars($other->name).'</a>';
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				return "{$userlink} assigned {$otherlink} to a task: {$tasklink}";
			
			case "comment": // comment added
				$comment = new CommentModel($this->content);
				$commentlink = '<a href="'.$comment->getLink().'">'.$view->excerpt($comment->text).'</a>';
				return "{$userlink} added a comment: {$commentlink}";
			
			case "complete": // user completed task
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				return "{$userlink} completed a task: {$tasklink}";
			
			case "move": // user moved task
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				return "{$userlink} moved a task: {$tasklink}";
			
			case "project": // new project created
				$project = new ProjectModel($this->project);
				$projectlink = '<a href="'.$view->url(array('id'=>$project->link),"project",true).'">'.htmlspecialchars($project->name).'</a>';
				return "{$userlink} created a new project: {$projectlink}";

			case "reopen": // user reopened task
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				return "{$userlink} reopened a task: {$tasklink}";
			
			case "resource": // resource added
				$resource = new ResourceModel($this->content);
				$resourcelink = '<a href="'.$resource->getLink().'">'.($resource->description ? $resource->description : $resource->content).'</a>';
				return "{$userlink} added a resource: {$resourcelink}";
			
			case "task": // new task created
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				return "{$userlink} created a new task: {$tasklink}";
			
			case "timelog": // time has been logged
				$task = new TaskModel($this->task);
				$tasklink = '<a href="'.$view->url(array('id'=>$task->id),"task",true).'">'.$view->excerpt($task->title).'</a>';
				$time = $view->time($this->content);
				return "{$userlink} logged {$time} hours in: {$tasklink}";
			
			case "user": // new user created
				$other = new UserModel($this->content);
				$otherlink = '<a class="user" href="'.$view->url(array('id'=>$other->id),"user",true).'">'.htmlspecialchars($other->name).'</a>';
				return "{$userlink} added a new user: {$otherlink}";
				
			default:
				return "UNRECOGNIZED FEED FORMAT";
		}
	}
	
	/**
	* Gets the icon associated with the feed item.
	* @return string
	**/
	public function getIcon()
	{
		switch($this->type)
		{
			case "assign":
				return "task";
				
			case "user":
				return "users";
				
			default:
				return $this->type;
		}
	}
	
	// OVERWRITTEN FROM MODEL

	public function getLink()
	{
		$view = Zend_Layout::getMvcInstance()->getView();

		switch($this->type)
		{
			case "abandon": // user abandoned task
				$task = new TaskModel($this->task);
				return $view->url(array('id'=>$task->id),"task",true);

			case "assign": // user assigned a task
				$task = new TaskModel($this->task);
				return $view->url(array('id'=>$task->id),"task",true);

			case "comment": // comment added
				$comment = new CommentModel($this->content);
				return $comment->getLink();

			case "complete": // user completed task
				$task = new TaskModel($this->task);
				return $view->url(array('id'=>$task->id),"task",true);

			case "project": // new project created
				$project = new ProjectModel($this->project);
				return $view->url(array('id'=>$project->link),"project",true);

			case "reopen": // user reopened task
				$task = new TaskModel($this->task);
				return $view->url(array('id'=>$task->id),"task",true);

			case "resource": // resource added
				$resource = new ResourceModel($this->content);
				return $resource->getLink();

			case "task": // new task created
				$task = new TaskModel($this->task);
				return $view->url(array('id'=>$task->id),"task",true);

			case "timelog": // time has been logged
				$task = new TaskModel($this->task);
				return $view->url(array('id'=>$task->id),"task",true);

			case "user": // new user created
				$other = new UserModel($this->content);
				return $view->url(array('id'=>$other->id),"user",true);

			default:
				return parent::getLink();
		}
	}

	public function save()
	{
		$view = Zend_Layout::getMvcInstance()->getView();

		if(empty($this->project))
			$this->project = null;
		if(empty($this->task))
			$this->task = null;
		if(empty($this->content))
			$this->content = null;
		if(empty($this->user) && $view->currentUser())
			$this->user = $view->currentUser()->id;
		if(empty($this->date))
			$this->date = date("Y-m-d H:i:s");
		parent::save();
	}
}
