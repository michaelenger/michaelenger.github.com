<?php

/**
* TaskModel
**/
class TaskModel extends Model
{
	// id
	public $project = 0;
	public $title = "";
	public $description = "";
	public $type = null;
	public $date_created = null;
	public $created_by = 0;
	public $date_due = null;
	public $date_completed = null;
	public $completed_by = null;
	public $priority = 0;
	
	/**
	* Contstructor.
	* @param entry An id or array to initialize with.
	**/
	public function TaskModel($entry = null)
	{
		parent::init("task", $entry);
	}
	
	/**
	* Adds a time to the task.
	* @param timelog An array with the entries user, amount, description and date.
	**/
	public function addTime($timelog)
	{
		$db = Zend_Registry::getInstance()->database;
		$timelog['task'] = $this->id;
		$db->insert("task_timelog", $timelog);
	}
	
	/**
	* Adds a user to the task.
	* @param user A UserModel or id.
	**/
	public function addUser($user)
	{
		$db = Zend_Registry::getInstance()->database;
		$view = Zend_Layout::getMvcInstance()->getView();
		if(is_object($user)) $user = $user->id;
		
		$array = array(
			'task' => $this->id,
			'user' => $user
		);
		
		$db->insert("task_assignment", $array);
	}
	
	/**
	* Completes the task.
	* @param user The user that completed the task.
	**/
	public function complete($user)
	{
		if($this->isComplete())
			return;
		
		if(is_object($user)) $user = $user->id;
		$this->completed_by = $user;
		$this->date_completed = date("Y-m-d H:i:s");
		$this->save();
	}
	
	/**
	* Gets the comments associated with this task.
	* @return array
	**/
	public function getComments()
	{
		$db = Zend_Registry::getInstance()->database;
		$result = $db->fetchAll("SELECT * FROM comment WHERE type = 'task' AND parent = '{$this->id}' ORDER BY id ASC");
		$comments = array();
		foreach($result as $entry)
			$comments[$entry['id']] = new CommentModel($entry);
		return $comments;
	}
	
	/**
	* Gets the total amount of hours spent on this task.
	* @return number
	**/
	public function getHours()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchRow("
			SELECT SUM(amount) AS hours FROM task_timelog
			WHERE task = '{$this->id}'
		");
		
		if($result['hours'])
			return $result['hours'];
		else
			return 0;
	}
	
	/**
	* Gets the status of the task.
	* @return string
	**/
	public function getStatus()
	{
		$users = $this->getUsers();
		if($this->isComplete())
			return "complete";
		elseif(!empty($users))
			return "active";
		else
			return "abandoned";
	}
	
	/**
	* Gets the list of timelogs.
	* @return array
	**/
	public function getTimelog($sort = null, $order = null, $limit = null)
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Default values
		if(!$sort) $sort = "id";
		if(!$order) $order = "ASC";
		
		// Build SQL
		$sql = "
			SELECT * FROM task_timelog
			WHERE task = '{$this->id}'
			ORDER BY {$sort} {$order}
		";
		if($limit) $sql .= " LIMIT {$limit}";
		
		// Get timelog
		$result = $db->fetchAll($sql);
		
		return $result;
	}
	
	/**
	* Gets the users associated with this task.
	* @return array
	**/
	public function getUsers()
	{
		$db = Zend_Registry::getInstance()->database;
		
		$result = $db->fetchAll("
			SELECT user.* FROM user,task_assignment
			WHERE user.id = task_assignment.user
			AND task_assignment.task = '{$this->id}'
			ORDER BY user.name
		");
		
		$users = array();
		foreach($result as $entry)
			$users[$entry['id']] = new UserModel($entry);
		return $users;
	}
	
	/**
	* Checks whether the user has the user as a creator or assigned to it.
	* @param user A UserModel or id
	* @return boolean
	**/
	public function hasUser($user)
	{
		if(is_object($user)) $user = $user->id;
		return ($user == $this->created_by || array_key_exists($user, $this->getUsers()));
	}
	
	/**
	* Checks whether the task is complete.
	* @return boolean
	**/
	public function isComplete()
	{
		return $this->date_completed != null;
	}
	
	/**
	* Removes a user from the task.
	* @param user A UserModel or id.
	**/
	public function removeUser($user)
	{
		$db = Zend_Registry::getInstance()->database;
		if(is_object($user)) $user = $user->id;
		
		$db->delete("task_assignment", "task = '{$this->id}' AND user = '{$user}'");
	}

	/**
	* Re-open the task.
	**/
	public function reopen()
	{
		if(!$this->isComplete())
			return;

		$this->completed_by = null;
		$this->date_completed = null;
		$this->save();
	}
	
	// OVERWRITTEN FROM MODEL
	
	public function delete()
	{
		$db = Zend_Registry::getInstance()->database;
		
		// Delete all task assignments
		$db->delete("task_assignment", "task = '{$this->id}'");
		
		// Delete all timelogs
		$db->delete("task_timelog", "task = '{$this->id}'");
		
		// Delete all feed items
		$db->delete("feed", "task = '{$this->id}'");
		
		// Delete		
		parent::delete();
	}
	
	public function save()
	{
		if(empty($this->type))
			$this->type = null;
		if(empty($this->date_due))
			$this->date_due = null;
		if(empty($this->date_completed))
			$this->date_completed = null;
		if(empty($this->completed_by))
			$this->completed_by = null;
		parent::save();
	}
	
	public function validate()
	{
		$errors = array();
		
		if(empty($this->title))
			$errors['title'] = "Cannot be empty";
		
		return $errors;
	}
}