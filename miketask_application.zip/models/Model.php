<?php

/**
* Model
* Abstract superclass for handling models within the application.
**/
abstract class Model
{
	// Table name
	protected $_table = null;
	// Unique id (all tables have this)
	public $id = null;
	
	/**
	* Removes the model from the database.
	**/
	public function delete()
	{
		$db = Zend_Registry::getInstance()->database;
		$db->delete($this->_table, "id = '{$this->id}'");
		
		foreach($this as $key => $value)
			if($key != "_table")
				unset($this->$key);
	}
	
	/**
	* Takes information from an array and sets it into the model.
	* @param array An array of key/values that need to be incorporated into the model.
	* @param slashed Whether the array uses escaped quotes or not (default: false).
	**/
	public function fromArray($array, $slashed = false)
	{
		foreach($this as $key => $value)
		{
			if(isset($array[$key]))
			{
				if($slashed && strpos($array[$key], "\\") !== false) $array[$key] = stripslashes($array[$key]);
				$this->$key = trim($array[$key]);
			}
		}
	}
	
	/**
	* Returns a link to the specified model.
	* @return string
	**/
	public function getLink()
	{
		return "#";
	}
	
	/**
	* Initializes the model by setting the table name.
	* @param table The name of the associated table in the database.
	* @param model The id of the entry or an array containing the information.
	**/
	public function init($table, $model = null)
	{
		// Set table
		$this->_table = $table;
		
		if(!$model) return; // no model, then completed
		
		if(is_array($model)) // extract data from array
		{
			foreach($model as $key => $value)
				$model[$key] = stripslashes($value); // assumes the data was from the database (so slashed)
			$this->fromArray($model);
			return;
		}
		else // read database
			$id = $model;
		
		//Set id
		$this->id = $id;
		
		// Load data
		$db = Zend_Registry::getInstance()->database;
		$array = $db->fetchRow("SELECT * FROM {$this->_table} WHERE id = '{$this->id}'");
		if(!$array) throw new Exception("Model.init: Id '{$this->id}' not found in table '{$this->_table}'");
		$array = array_map('stripslashes', $array); // all data in the database should be slashed
		$this->fromArray($array);
	}
	
	/**
	* Saves the model to the database.
	**/
	public function save()
	{
		if(!$this->_table || $this->_table == "") throw new Exception("[Model::save] Table not set");
		
		// Variables
		$array = $this->toArray();
		$db = Zend_Registry::getInstance()->database;
		
		// Add slashes to avoid simple SQL attacks
		foreach($array as $key => $value)
			if($value != null)
				$array[$key] = addslashes($value);
		
		// Saves
		if(isset($this->id) && $this->id != null && $this->id != "") // id exists
		{
			$db->update($this->_table, $array, "id = '{$this->id}'");
		}
		else // create new
		{
			$db->insert($this->_table, $array);
			$this->id = $db->lastInsertId();
		}
		
		// Update self info
		$this->fromArray(array_map('stripslashes', $db->fetchRow("SELECT * FROM {$this->_table} WHERE id = '{$this->id}'")));
	}
	
	/**
	* Creates an array with key/values out of the values in the model.
	* @return array
	**/
	public function toArray()
	{
		$array = array();
		
		foreach($this as $key => $value)
			$array[$key] = $value;
		
		unset($array['_table']); // don't need this
		
		return $array;
	}
	
	/**
	* Validates the information in the Model.
	* @return array of errors
	**/
	public function validate()
	{
		return array();
	}
}
