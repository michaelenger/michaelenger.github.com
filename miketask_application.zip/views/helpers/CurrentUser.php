<?php

/**
* CurrentUser
* Gets the current user.
**/
class View_Helper_CurrentUser extends Zend_View_Helper_Abstract
{
	/**
	* Gets the currently logged in user.
	* @return UserModel
	**/
	function currentUser()
	{
		$registry = Zend_Registry::getInstance();
		return $registry->user;
	}
}
