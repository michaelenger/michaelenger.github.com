<?php

/**
* PriorityList
* Gets a list of priority names.
**/
class View_Helper_PriorityList extends Zend_View_Helper_Abstract
{
	/**
	* Gets a list of priority names.
	* @return array
	**/
	function priorityList()
	{
		$array = array(
			2 => 'Very High',
			1 => 'High',
			0 => 'Normal',
			-1 => 'Low',
			-2 => 'Very Low'
		);
		
		return $array;
	}
}
