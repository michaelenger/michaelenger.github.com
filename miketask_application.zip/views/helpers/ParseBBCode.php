<?php

/**
* ParseBBCode
* Parses BBCode-style text into HTML.
**/
class View_Helper_ParseBBCode extends Zend_View_Helper_Abstract
{
	/**
	* Parses the text, formatting it as required.
	* @text The text to be formatted.
	* @return string
	**/
	function parseBBCode($text)
	{
		$view = Zend_Layout::getMvcInstance()->getView();
		
		$text = htmlspecialchars($text);
		
		// Simple text formatting
		$text = preg_replace("/\[b\](.+?)\[\/b\]/is", '<span class="bold">$1</span>', $text);
		$text = preg_replace("/\[i\](.+?)\[\/i\]/is", '<span class="italic">$1</span>', $text);
		$text = preg_replace("/\[s\](.+?)\[\/s\]/is", '<span class="strikethrough">$1</span>', $text);
		$text = preg_replace("/\[u\](.+?)\[\/u\]/is", '<span class="underline">$1</span>', $text);
		$text = preg_replace("/\[size=(.+?)\](.+?)\[\/size\]/is", '<span style="font-size:$1%">$2</span>', $text);
		$text = preg_replace("/\[color=(.+?)\](.+?)\[\/color\]/is", '<span style="color:$1">$2</span>', $text);
		
		// Link
		//   [url]LINK[/url]
		//   [url=LINK]TEXT[/url]
		$text = preg_replace("/\[url\](.+?)\[\/url\]/i", '<a href="$1">$1</a>', $text);
		$text = preg_replace("/\[url=(.+?)\](.+?)\[\/url\]/i", '<a href="$1">$2</a>', $text);
		
		// Image
		//   [img]NUM|LINK[/img]
		$text = preg_replace("/\[(img)\](.+?)\[\/(img)\]/i", '<img src="$2" alt="" />', $text); // external
		
		// Blockquote & Code
		//   [quote]TEXT[/quote]
		//   [quote=PERSON]TEXT[/quote]
		//   [code]TEXT[/code]
		$text = preg_replace("/\[quote(=(.+?))?\](.+?)\[\/quote\]/ie", "'<blockquote><p>' . ('$1' != null ? '<cite>$2</cite>' : '') . '$3</p></blockquote>'", $text);
		$text = preg_replace("/\[code\](.+?)\[\/code\]/i", '<code>$1</code>', $text);
		
		// Lists
		preg_match_all("/\[list(.*?)\](.+?)\[\/list\]/is", $text, $out, PREG_SET_ORDER);
		foreach($out as $list)
		{
			if(count($list) == 0) continue;
			$temp = $list[0];
			
			$temp = preg_replace("/\[list=(\d)\](.+?)\[\/list\]/is", '<ol class="numeric">$2</ol>', $temp);
			$temp = preg_replace("/\[list=(\D)\](.+?)\[\/list\]/is", '<ol class="alpha">$2</ol>', $temp);
			$temp = preg_replace("/\[list\](.+?)\[\/list\]/is", '<ul class="bullet">$1</ul>', $temp);
			$temp = preg_replace("/\[\*\](.+)(\n?)/i", '<li>$1</li>', $temp);
			
			$text = str_replace($list[0],$temp,$text);
		}
		
		// Flash
		//   [flash]LINK[/flash]
		//   [flash=WIDTH,HEIGHT]LINK[/flash]
		//$text = preg_replace("/\[flash(=(\d+?),(\d+?))?\](.+?)\[\/flash\]/ie", "'<object style=\"width:' . ('$2' == null ? '490' : '$2') . 'px;height:' . ('$3' == null ? '275' : '$3') . 'px;\" type=\"application/x-shockwave-flash\" width=\"' . ('$2' == null ? '490' : '$2') . '\" height=\"' . ('$3' == null ? '275' : '$3') . '\" data=\"$4\"><param name=\"movie\" value=\"$4\" /></object>'", $text);
		
		// Line-breaks
		$text = nl2br($text);
		
		// Encforce XHTML Strict
		$text = preg_replace("/\<([ul]|[ol])(.*?)><br \/>/i", '<$1$2>', $text);
		
		return $text;
	}
}
