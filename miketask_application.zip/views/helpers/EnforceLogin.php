<?php

/**
* EnforceLogin
* Redirects a non-logged in user to the login screen.
**/
class View_Helper_EnforceLogin extends Zend_View_Helper_Abstract
{
	/**
	* Redirects a non-logged in user to the login screen.
	**/
	function enforceLogin()
	{
		$view = Zend_Layout::getMvcInstance()->getView();
		if(!$view->currentUser())
			$view->redirect("user","login", array(), "?redirect=" . $view->url());
	}
}
