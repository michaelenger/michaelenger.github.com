<?php

/**
* SplitList
* Splits a serialized list into array values.
**/
class View_Helper_SplitList extends Zend_View_Helper_Abstract
{
	/**
	* Splits a string of type "key[]=value1&key[]=value2..." into an array of values.
	* @param string The string to split.
	* @return array
	**/
	function splitList($string)
	{
		preg_match_all("/(.+?)\[\]=(\d+)/i", $string, $matches, PREG_SET_ORDER);
		$list = array();
		foreach($matches as $match)
			$list[] = $match[2];
		return $list;
	}
}
