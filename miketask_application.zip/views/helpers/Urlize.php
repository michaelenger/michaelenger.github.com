<?php

require_once APPLICATION_PATH . "/models/UserModel.php";

/**
* Urlize
* Makes a URL-friendly version of a string.
**/
class View_Helper_Urlize extends Zend_View_Helper_Abstract
{
	/**
	* Returns a URL-friendly version of a string.
	* @param string A line of text.
	* @return string
	**/
	function urlize($string)
	{
		$string = preg_replace("/[\s]/", "-", $string);
		$string = preg_replace("/[^\w-]/", "", $string);
		$string = strtolower($string);
		return $string;
	}
}
