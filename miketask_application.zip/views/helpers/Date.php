<?php

/**
* Date
* Formats the timestamp as a readable date.
**/
class View_Helper_Date extends Zend_View_Helper_Abstract
{
	/**
	* Formats the timestamp as a readable date in the type:  January 30th, 2009 10:33
	* @param date A unix timestamp.
	* @param time Include the time (default: false).
	* @return string
	**/
	function date($date, $time = false)
	{
		if(!is_numeric($date))
			$date = strtotime($date);
		
		if($time)
			return date("F jS, Y H:i", $date);
		else
			return date("F jS, Y", $date);
	}
}
