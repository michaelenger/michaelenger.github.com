<?php

/**
* Excerpt
* Gets an excerpt from a piece of text.
**/
class View_Helper_Excerpt extends Zend_View_Helper_Abstract
{
	/**
	* Gets an excerpt from the passed string.
	* @param text Text to shorten.
	* @param length The length to shorten to (default: 50)
	* @return string
	**/
	function excerpt($text, $length = 50)
	{
		//$text = strip_tags($text);
		if(strlen($text) > $length)
			$text = substr($text, 0, $length - 3) . "...";
		return htmlspecialchars($text);
	}
}
