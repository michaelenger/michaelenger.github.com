<?php

/**
* Username
* Gets the username of a user.
**/
class View_Helper_Username extends Zend_View_Helper_Abstract
{
	/**
	* Gets the username of the specified user.
	* @param user A UserModel or id.
	* @return string
	**/
	function username($user)
	{
		if(!is_object($user))
			$user = new UserModel($user);
		
		return $user->name;
	}
}
