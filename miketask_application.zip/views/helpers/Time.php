<?php

/**
* Time
* Formats number as a readable time.
**/
class View_Helper_Time extends Zend_View_Helper_Abstract
{
	/**
	* Formats the number as a readable time: 10:33
	* @param time A numerical value (in hours).
	* @param showfull Whether to allow the display to split the hours up into days (where needed) (default: false)
	* @return string
	**/
	function time($time, $showfull = false)
	{
		if(!is_numeric($time)) return "";
		
		$hours = floor($time);
		$minutes = ($time - $hours) * 60;
		if($minutes < 10) $minutes = "0" . $minutes;
		
		
		if(!$showfull)
			return "{$hours}:{$minutes}";
		
		$minutes = intval($minutes);
		return ($hours > 24 ? floor($hours / 24) . " day" . (floor($hours / 24) > 1 ? "s" : "") . " " . ($hours % 24) : $hours) . " hours " . ($minutes > 0 ? "{$minutes} minutes" : "");
	}
}
