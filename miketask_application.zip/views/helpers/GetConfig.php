<?php

/**
* GetConfig
* Gets a configuration item.
**/
class View_Helper_GetConfig extends Zend_View_Helper_Abstract
{
	/**
	* Gets a configuration item.
	* @param key Name of the item to retrieve.
	* @return string
	**/
	function getConfig($key)
	{
		$registry = Zend_Registry::getInstance();
		return $registry->config->$key;
	}
}
