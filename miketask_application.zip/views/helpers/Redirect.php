<?php

/**
* Redirect
* Redirects to the specified controller/action.
**/
class View_Helper_Redirect extends Zend_View_Helper_Abstract
{
	/**
	* Redirects to the specified controller by setting the header location.
	* @param controller The controller to redirect to.
	* @param action The action to redirect to (default: index).
	* @param params An array of parameters (default: empty array).
	**/
	function redirect($controller, $action = null, $params = array(), $append = "")
	{
		$view = Zend_Layout::getMvcInstance()->getView();
		if($action) $params['action'] = $action;
		header("Location: " . $view->url($params, $controller, true) . $append);
		die(); // prevents any more processing
	}
}
