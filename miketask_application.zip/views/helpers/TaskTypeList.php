<?php

/**
* TaskTypeList
* Gets a list of task types.
**/
class View_Helper_TaskTypeList extends Zend_View_Helper_Abstract
{
	/**
	* Gets a list of task types.
	* @return array
	**/
	function taskTypeList()
	{
		return array(
			'other' => "Other",
			'bug' => "Bug",
			'feature' => "Feature"
		);
	}
}
