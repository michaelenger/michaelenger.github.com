<?php

// Includes
require_once APPLICATION_PATH . "/models/Models.php";

// Setup the front controller
$frontController = Zend_Controller_Front::getInstance();
$frontController->setControllerDirectory(APPLICATION_PATH . "/controllers");

// Custom routes
$router = $frontController->getRouter();
// Index
$router->addRoute('index', new Zend_Controller_Router_Route(
	':controller/:action',
	array(
		'controller' => "index",
		'action' => "index"
	)
));
// Comment
$router->addRoute('comment', new Zend_Controller_Router_Route(
	'comment/:action/:id',
	array(
		'controller' => "comment",
		'action' => "index",
		'id' => ""
	)
));
// Feed
$router->addRoute('feed', new Zend_Controller_Router_Route(
	'feed/:action',
	array(
		'controller' => "feed",
		'action' => "index"
	)
));
// Project
$router->addRoute('project', new Zend_Controller_Router_Route(
	'project/:id/:action',
	array(
		'controller' => "project",
		'id' => "",
		'action' => "view"
	)
));
// Projects
$router->addRoute('projects', new Zend_Controller_Router_Route(
	'projects',
	array(
		'controller' => "project",
		'action' => "index"
	)
));
// Resource
$router->addRoute('resource', new Zend_Controller_Router_Route(
	'resource/:action/:id',
	array(
		'controller' => "resource",
		'action' => "index",
		'id' => ""
	)
));
// RSS
$router->addRoute('rss', new Zend_Controller_Router_Route(
	'rss/:action/:id',
	array(
		'controller' => "rss",
		'action' => "all",
		'id' => ""
	)
));
// Task
$router->addRoute('task', new Zend_Controller_Router_Route(
	'task/:id/:action',
	array(
		'controller' => "task",
		'action' => "view",
		'id' => ""
	)
));
// Tasks
$router->addRoute('tasks', new Zend_Controller_Router_Route(
	'tasks',
	array(
		'controller' => "task",
		'action' => "index"
	)
));
// Timelog
$router->addRoute('timelog', new Zend_Controller_Router_Route(
	'timelog/:action/:id',
	array(
		'controller' => "timelog",
		'action' => "list",
		'id' => ""
	)
));
// User
$router->addRoute('user', new Zend_Controller_Router_Route(
	'user/:action/:id',
	array(
		'controller' => "user",
		'action' => "profile",
		'id' => ""
	)
));
// Users
$router->addRoute('users', new Zend_Controller_Router_Route(
	'users',
	array(
		'controller' => "user",
		'action' => "index"
	)
));

// Layout
Zend_Layout::startMvc(APPLICATION_PATH . "/views/layouts");
$view = Zend_Layout::getMvcInstance()->getView();
$view->layout()->setLayout("default");

$doctypeHelper = new Zend_View_Helper_Doctype();
$doctypeHelper->doctype('XHTML1_TRANSITIONAL');

// Config
$config = new Zend_Config_Ini(APPLICATION_PATH . "/config.ini", APPLICATION_ENVIRONMENT);

// DB
$db = Zend_Db::factory($config->database);

// View information
$view->headTitle($config->title)->setSeparator($config->separator);
$view->headMeta()->appendName('author',$config->author)
				 ->appendName('description',$config->description)
				 ->appendName('keywords',$config->keywords)
				 ->appendName('robots', 'noindex,nofollow');
$view->basepath = $config->base;

// Registry (for global vars)
$registry = Zend_Registry::getInstance();
$registry->config = $config;
$registry->database = $db;
$registry->user = null;

// Logged in user
$session = new Zend_Session_Namespace('miketask');
if(isset($session->user) && $session->user != null)
{
	$user = $session->user;
	$registry->user = $user;
	if(isset($_COOKIE['miketask_user'])) // refresh the cookie
	{
		setcookie("miketask_user", $user->id, time()+60*60*24*7, "/");
		setcookie("miketask_hash", $user->password, time()+60*60*24*7, "/");
	}
	unset($user);
}
elseif(isset($_COOKIE['miketask_user']) && isset($_COOKIE['miketask_hash']))
{
	$user = new UserModel($_COOKIE['miketask_user']);
	if($_COOKIE['miketask_hash'] == $user->password)
		$registry->user = $user;
	unset($user);
}

// Helper classes
$view->addHelperPath(APPLICATION_PATH . "/views/helpers", "View_Helper");

// Cleanup
unset($frontController, $router, $lang, $view, $doctypeHelper, $config, $db);

