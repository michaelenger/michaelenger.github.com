<?php

/**
* UserController
* Controls user actions.
**/
class UserController extends Zend_Controller_Action
{
	/**
	* Default action.
	**/
	public function indexAction()
	{
		$this->view->enforceLogin();
		
		$this->view->users = Models::getUsers();
		$this->view->headTitle("Users", 'PREPEND');
	}
	
	/**
	* Add new user.
	**/
	public function addAction()
	{
		$this->view->enforceLogin();
		
		// Variables
		$errors = array();
		$user = new UserModel();
		
		// Add user
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			$user->fromArray($post, get_magic_quotes_gpc());
			
			$errors = $user->validate();
			
			if($post['password'] != $post['repeat_password'])
				$errors['repeat_password'] = "Must be the same as the password";
			
			if(Models::getUserByEmail($user->email))
				$errors['email'] = "A user with that email already exists";
			
			if(empty($errors))
			{
				// Create user
				$user->password = sha1($user->password);
				$user->parent = $this->view->currentUser()->id;
				$user->save();
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "user";
				$feed->content = $user->id;
				$feed->date = $user->date_created;
				$feed->user = $user->parent;
				$feed->save();
				
				// Redirect
				$this->view->redirect("users");
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->user = $user;
	}
	
	/**
	* Shows the feed items associated with the specified user.
	**/
	public function feedAction()
	{
		$this->view->enforceLogin();
		
		if($this->getRequest()->getParam("id"))
			$user = new UserModel($this->getRequest()->getParam("id"));
		else
			$user = $this->view->currentUser();
		
		$this->view->user = $user;
		$this->view->feed = $user->getFeed($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->rss = $this->view->url(array('action'=>"user",'id'=>$user->id), "rss", true);
		$this->view->headTitle($user->name, 'PREPEND');
	}
	
	/**
	* Shows a header.
	**/
	public function headerAction()
	{
		$this->view->enforceLogin();
		
		$this->view->current = Zend_Controller_Front::getInstance()->getRequest()->getActionName();
		$this->view->menu = array(
			'profile' => "Profile",
			'feed' => "Feed",
			'projects' => "Projects",
			'tasks' => "Assignments",
			'timelog' => "Timelog"
		);
	}
	
	/**
	* Lists all the users.
	* If the view variables "users" isn't set it lists all the users.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->users))
			$this->view->users = Models::getUsers();
	}
	
	/**
	* Attempt to log in.
	**/
	public function loginAction()
	{
		// Variables
		$error = "";
		$redirect = "";
		$remember = false;
		$user = new UserModel();
		
		if($this->getRequest()->getParam("redirect"))
			$redirect = $this->getRequest()->getParam("redirect");
		
		// Login
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			$user->fromArray($post, get_magic_quotes_gpc());
			if(isset($post['remember']))
				$remember = true;
			if(empty($redirect))
				$redirect = $post['redirect'];
			
			if($user->login())
			{
				$session = new Zend_Session_Namespace('miketask');
				$session->user = $user;
				
				if($remember)
				{
					setcookie("miketask_user", $user->id, time()+60*60*24*7, "/");
					setcookie("miketask_hash", $user->password, time()+60*60*24*7, "/");
				}
				
				if(!empty($redirect))
					header("Location: {$redirect}");
				else
					$this->view->redirect("index");
				die(); // to ensure that the redirect is followed
			}
			else
				$error = "Authentication failed";
		}
		
		// View variables
		$this->view->error = $error;
		$this->view->redirect = $redirect;
		$this->view->remember = $remember;
		$this->view->user = $user;
		$this->view->headTitle("Login", 'PREPEND');
	}
	
	/**
	* Log the current user out.
	**/
	public function logoutAction()
	{
		$session = new Zend_Session_Namespace('miketask');
		if(isset($session->user))
			unset($session->user);
		
		setcookie("miketask_user", "", time()-1, "/");
		setcookie("miketask_hash", "", time()-1, "/");
		
		$this->view->redirect("index");
	}
	
	/**
	* Shows a user profile.
	**/
	public function profileAction()
	{
		$this->view->enforceLogin();
		
		if($this->getRequest()->getParam("id"))
			$user = new UserModel($this->getRequest()->getParam("id"));
		else
			$user = $this->view->currentUser();
		
		$this->view->user = $user;
		$this->view->comments = $user->getComments(5);
		$this->view->feed = $user->getFeed($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"), 5);
		$this->view->projects = $user->getProjects();
		$this->view->rss = $this->view->url(array('action'=>"user",'id'=>$user->id), "rss", true);
		$this->view->headTitle($user->name, 'PREPEND');
	}
	
	/**
	* Shows the projects associated with the specified user.
	**/
	public function projectsAction()
	{
		$this->view->enforceLogin();
		
		if($this->getRequest()->getParam("id"))
			$user = new UserModel($this->getRequest()->getParam("id"));
		else
			$user = $this->view->currentUser();
		
		$this->view->user = $user;
		$this->view->projects = $user->getProjects();
		$this->view->rss = $this->view->url(array('action'=>"user",'id'=>$user->id), "rss", true);
		$this->view->headTitle($user->name, 'PREPEND');
	}
	
	/**
	* Edit the user's settings.
	**/
	public function settingsAction()
	{
		$this->view->enforceLogin();
		
		// Variables
		$errors = array();
		$user = $this->view->currentUser();
		
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			
			// Edit user
			if(isset($post['edit_user']))
			{
				$user->fromArray($post, get_magic_quotes_gpc());
				
				if(!empty($_FILES['upload']['name']))
				{
					if($_FILES['upload']['error'] != 0) throw new Exception("[UserController::settingsAction] File upload error: {$_FILES['upload']['error']}");
					
					$filename = $user->id . "_" . date("U") .substr($_FILES['upload']['name'], strrpos($_FILES['upload']['name'],"."));
					
					if(!move_uploaded_file($_FILES['upload']['tmp_name'], "avatar/{$filename}"))
						throw new Exception("[UserController::settingsAction] Unable to move uploaded file");
					else
					{
						if(!empty($user->avatar))
							unlink("avatar/{$user->avatar}");
						$user->avatar = $filename;
					}
				}
				
				$errors = $user->validate();
				
				// Check if email is already existing
				$other = Models::getUserByEmail($user->email);
				if($other && $other->id != $user->id)
					$errors['email'] = "A user with that email already exists";
				
				if(empty($errors))
					$user->save();
			}
			
			// Change password
			if(isset($post['edit_password']))
			{
				$post = array_map("trim", $post);
				if(sha1($post['old_password']) != $user->password)
					$errors['old_password'] = "Incorrect password";
				if(empty($post['password']))
					$errors['password'] = "Cannot be empty";
				if($post['repeat_password'] != $post['password'])
					$errors['repeat_password'] = "Must be the same as the password";
				
				if(empty($errors))
				{
					$user->password = sha1($post['password']);
					$user->save();
				}
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->user = $user;
		$this->view->rss = $this->view->url(array('action'=>"user",'id'=>$user->id), "rss", true);
	}
	
	/**
	* Shows the tasks associated with the specified user.
	**/
	public function tasksAction()
	{
		$this->view->enforceLogin();
		
		if($this->getRequest()->getParam("id"))
			$user = new UserModel($this->getRequest()->getParam("id"));
		else
			$user = $this->view->currentUser();
		
		// View variables
		$this->view->user = $user;
		$this->view->tasks = $user->getTasks($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->rss = $this->view->url(array('action'=>"user",'id'=>$user->id), "rss", true);
		$this->view->headTitle($user->name, 'PREPEND');
	}

	/**
	* Shows the timelogs associated with the specified user.
	**/
	public function timelogAction()
	{
		$this->view->enforceLogin();
		
		$type = "list";
		if($this->getRequest()->getParam("type")) $type = $this->getRequest()->getParam("type");
		
		if($this->getRequest()->getParam("id"))
			$user = new UserModel($this->getRequest()->getParam("id"));
		else
			$user = $this->view->currentUser();
		
		// View variables
		$this->view->user = $user;
		$this->view->timelog = $user->getTimelog($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->type = $type;
		$this->view->rss = $this->view->url(array('action'=>"user",'id'=>$user->id), "rss", true);
		$this->view->headTitle($user->name, 'PREPEND');
	}
}
