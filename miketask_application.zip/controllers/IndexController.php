<?php

/**
* IndexController
* The default controller.
**/
class IndexController extends Zend_Controller_Action
{
	/**
	* Shows the front page.
	**/
	public function indexAction()
	{
		if($this->view->currentUser())
			$this->view->redirect("feed");
		else
			$this->view->redirect("user", "login");
	}
}
