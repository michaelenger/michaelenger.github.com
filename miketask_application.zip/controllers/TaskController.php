<?php

/**
* TaskController
**/
class TaskController extends Zend_Controller_Action
{
	/**
	* Default action.
	**/
	public function indexAction()
	{
		$this->view->enforceLogin();
		
		$this->view->headTitle("Tasks", 'PREPEND');
	}
	
	/**
	* Remove logged in user from the task.
	**/
	public function abandonAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::abandonAction] Missing parameter: id");
		
		$error = "";
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::abandonAction] You don't have access to this task");
		
		// Remove user
		if($this->getRequest()->isPost())
		{
			// Remove user
			$task->removeUser($this->view->currentUser());
			
			// Create feed item
			$feed = new FeedModel();
			$feed->type = "abandon";
			$feed->project = $task->project;
			$feed->task = $task->id;
			$feed->user = $this->view->currentUser()->id;
			$feed->save();
			
			// Redirect
			$this->view->redirect("task", "view", array('id'=>$task->id));
		}
		
		// View variables
		$this->view->task = $task;
	}
	
	/**
	* Add new task.
	**/
	public function addAction()
	{
		$this->view->enforceLogin();
		
		// Variables
		$errors = array();
		$project = null;
		$task = new TaskModel();
		$user = $this->view->currentUser();
		
		if($this->getRequest()->getParam("project"))
			$project = new ProjectModel($this->getRequest()->getParam("project"));
		
		// Add task
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			$project = new ProjectModel($post['project']);
		
			$task->fromArray($post, get_magic_quotes_gpc());
			
			$errors = $task->validate();
			
			if(!$user->hasProject($project)) throw new Exception("[TaskController::addAction] You don't have access to this project");
			
			if(empty($errors))
			{
				// Create task
				$task->created_by = $user->id;
				$task->save();
				
				// Add current user
				$task->addUser($user);
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "task";
				$feed->project = $task->project;
				$feed->task = $task->id;
				$feed->date = $task->date_created;
				$feed->user = $task->created_by;
				$feed->save();
				
				// Redirect
				if (isset($post['add_task_repeat']))
					$this->view->redirect("task", "add", array(), "?project={$project->id}");
				else
					$this->view->redirect("task", "view", array('id'=>$task->id));
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->project = $project;
		$this->view->task = $task;
	}
	
	/**
	* Complete the task.
	**/
	public function completeAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::completeAction] Missing parameter: id");
		
		$error = "";
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::completeAction] You don't have access to this task");
		
		// Complete task
		if($this->getRequest()->isPost())
		{
			// Complete task
			$task->complete($this->view->currentUser());
			
			// Create feed item
			$feed = new FeedModel();
			$feed->type = "complete";
			$feed->project = $task->project;
			$feed->task = $task->id;
			$feed->user = $task->completed_by;
			$feed->date = $task->date_completed;
			$feed->save();
			
			// Redirect
			$this->view->redirect("task", "view", array('id'=>$task->id));
		}
		
		// View variables
		$this->view->task = $task;
	}
	
	/**
	* Edit the description of a task.
	**/
	public function descriptionAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::descriptionAction] Missing parameter: id");
		
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::priorityAction] You don't have access to this task");
		
		// Set priority
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();			
			$task->fromArray($post, get_magic_quotes_gpc());
			$task->save();
			$this->view->redirect("task", "view", array('id'=>$task->id));
		}
		
		// View variables
		$this->view->task = $task;
	}
	
	/**
	* Shows the header.
	**/
	public function headerAction()
	{
		$this->view->enforceLogin();
		
		if(!is_object($this->view->project))
			$this->view->project = new ProjectModel($this->view->task->project);
	}
	
	/**
	* Lists the tasks.
	* If the view variables "tasks" isn't set it lists all the tasks.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		$sort = $this->getRequest()->getParam("sort");
		$order = $this->getRequest()->getParam("order");
		
		if(!is_array($this->view->tasks))
			$this->view->tasks = Models::getTasks($sort, $order);
		
		$tasks = $this->view->tasks;
		
		// Show completed tasks
		$showcomplete = ($this->getRequest()->getParam("showcomplete") || ($this->view->project ? $this->view->project->archived : false));
		if (!$showcomplete) // remove all the completed tasks
		{
			$temp = array();
			foreach ($tasks as $task)
			{
				if (!$task->isComplete())
					$temp[] = $task;
			}
			$tasks = $temp;
		}
		
		// Filter by type
		$type = ($this->getRequest()->getParam("filter_type") ? $this->getRequest()->getParam("filter_type") : null);
		if ($type)
		{
			$temp = array();
			foreach ($tasks as $task)
			{
				if ($task->type == $type)
					$temp[] = $task;
			}
			$tasks = $temp;
		}
		
		$this->view->showcomplete = $showcomplete;
		$this->view->sort = $sort;
		$this->view->tasks = $tasks;
		$this->view->type = $type;
		$this->view->order = $order;
	}
	
	/**
	* Move the task.
	**/
	public function moveAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::moveAction] Missing parameter: id");
		
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::moveAction] You don't have access to this task");
		
		// Move
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			
			// Move task
			$task->project = $post['project'];
			$task->save();

			// Create feed item
			$feed = new FeedModel();
			$feed->type = "move";
			$feed->project = $task->project;
			$feed->task = $task->id;
			$feed->save();

			// Redirect
			$this->view->redirect("task", "view", array('id'=>$task->id));
		}
		
		// View variables
		$this->view->task = $task;
	}
	
	/**
	* Set the priority of a task.
	**/
	public function priorityAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::priorityAction] Missing parameter: id");
		
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::priorityAction] You don't have access to this task");
		
		// Set priority
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();			
			$task->fromArray($post, get_magic_quotes_gpc());
			$task->save();
			$this->view->redirect("task", "view", array('id'=>$task->id));
		}
		
		// View variables
		$this->view->task = $task;
	}

	/**
	* Re-open the task (un-complete it)
	**/
	public function reopenAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");

		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::reopenAction] Missing parameter: id");

		$error = "";
		$task = new TaskModel($this->getRequest()->getParam("id"));

		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::reopenAction] You don't have access to this task");

		// Reopen task
		if($this->getRequest()->isPost())
		{
			// Reopen task
			$task->reopen();

			// Create feed item
			$feed = new FeedModel();
			$feed->type = "reopen";
			$feed->project = $task->project;
			$feed->task = $task->id;
			$feed->save();

			// Redirect
			$this->view->redirect("task", "view", array('id'=>$task->id));
		}

		// View variables
		$this->view->task = $task;
	}
	
	/**
	* Allows a user to log time to the task.
	**/
	public function timelogAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::timelogAction] Missing parameter: id");
		
		$errors = array();
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::timelogAction] You don't have access to this task");
		
		$timelog = array(
			'user' => $this->view->currentUser()->id,
			'amount' => 0,
			'description' => "",
			'date' => date("Y-m-d")
		);
		
		// Add timelog
		if($this->getRequest()->isPost())
		{
			$post = array_map("trim", $this->getRequest()->getPost());
			
			$timelog['description'] = $post['description'];
			$timelog['date'] = $post['date'];
			//$timelog['amount'] = $post['amount'];
			
			$hours = 0;
			$minutes = 0;
			if(!empty($post['hours'])) $hours = $post['hours'];
			if(!empty($post['minutes'])) $minutes = $post['minutes'];
			
			if(!is_numeric($hours) || !is_numeric($minutes))
				$errors['amount'] = "Values must be numeric";
			elseif((int)$hours <= 0 && (int)$minutes <= 0)
				$errors['amount'] = "Must be more than nothing";
			else
				$timelog['amount'] = (int)$hours + ((int)$minutes / 60);
			
			if(!preg_match("/^\d\d\d\d-\d\d-\d\d$/", $timelog['date']))
				$errors['date'] = "Must be formatted like so: YYYY-MM-DD";
			
			if(empty($errors))
			{
				// Add time
				$task->addTime($timelog);
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "timelog";
				$feed->project = $task->project;
				$feed->task = $task->id;
				$feed->content = $timelog['amount'];
				$feed->user = $this->view->currentUser()->id;
				$feed->save();
				
				// Redirect
				$this->view->redirect("task", "view", array('id'=>$task->id), "#timelog");
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->task = $task;
		$this->view->timelog = $timelog;
	}
	
	/**
	* Add users to the task.
	**/
	public function usersAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::usersAction] Missing parameter: id");
		
		$error = "";
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		if(!$task->hasUser($this->view->currentUser())) throw new Exception("[TaskController::usersAction] You don't have access to this task");
		
		// Add user
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			if($post['user'] != 0)
			{
				// Add user
				$task->addUser($post['user']);
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "assign";
				$feed->project = $task->project;
				$feed->task = $task->id;
				$feed->content = $post['user'];
				$feed->user = $this->view->currentUser()->id;
				$feed->save();
			}
		}
		
		// View variables
		$this->view->error = $error;
		$this->view->task = $task;
		$this->view->users = Models::getUsers();
	}
	
	/**
	* View a specific project.
	**/
	public function viewAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TaskController::viewAction] Missing parameter: id");
		
		$task = new TaskModel($this->getRequest()->getParam("id"));
		
		$this->view->task = $task;
		$this->view->comments = $task->getComments();
		$this->view->project = new ProjectModel($task->project);
		$this->view->timelog = $task->getTimelog($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->users = $task->getUsers();
		$this->view->headTitle($task->title, 'PREPEND');
	}
}
