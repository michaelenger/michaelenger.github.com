<?php

/**
* ResourceController
* Resources for projects.
**/
class ResourceController extends Zend_Controller_Action
{
	/**
	* Add a new file.
	**/
	public function fileAction()
	{
		$this->view->enforceLogin();
		
		// Variables
		$errors = array();
		$project = null;
		$resource = new ResourceModel();
		$user = $this->view->currentUser();
		
		if($this->getRequest()->getParam("project"))
			$project = new ProjectModel($this->getRequest()->getParam("project"));
		
		$resource->type = "file";
		
		// Add file
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			$project = new ProjectModel($post['project']);
			
			$resource->fromArray($post, get_magic_quotes_gpc());
			
			if(!empty($_FILES['content']['name']))
			{
				if($_FILES['content']['error'] != 0) throw new Exception("[ResourceController::fileAction] File upload error: {$_FILES['content']['error']}");
				
				//$filename = $project->id ."_".date("U").substr($_FILES['content']['name'], strrpos($_FILES['content']['name'],"."));
				$filename = $project->id . "_" . date("U") . "_" . $_FILES['content']['name'];
				
				if(!move_uploaded_file($_FILES['content']['tmp_name'], "resource/{$filename}"))
					throw new Exception("[ResourceController::fileAction] Unable to move uploaded file");
				else
					$resource->content = $filename;
			}
			
			$errors = $resource->validate();
			
			if(!$user->hasProject($project)) throw new Exception("[ResourceController::fileAction] You don't have access to this project");
			
			if(empty($errors))
			{
				// Add file
				$resource->project = $project->id;
				$resource->user = $this->view->currentUser()->id;
				$resource->save();
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "resource";
				$feed->project = $resource->project;
				$feed->content = $resource->id;
				$feed->date = $resource->date;
				$feed->user = $resource->user;
				$feed->save();
				
				// Redirect
				$this->view->redirect("project", "resources", array('id'=>$project->link));
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->project = $project;
		$this->view->resource = $resource;
	}
	
	/**
	* Add a new link.
	**/
	public function linkAction()
	{
		$this->view->enforceLogin();
		
		// Variables
		$errors = array();
		$project = null;
		$resource = new ResourceModel();
		$user = $this->view->currentUser();
		
		if($this->getRequest()->getParam("project"))
			$project = new ProjectModel($this->getRequest()->getParam("project"));
		
		$resource->type = "link";
		
		// Add link
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			$project = new ProjectModel($post['project']);
			
			$resource->fromArray($post, get_magic_quotes_gpc());
			
			$errors = $resource->validate();
			
			if(!$user->hasProject($project)) throw new Exception("[ResourceController::linkAction] You don't have access to this project");
			
			if(empty($errors))
			{
				// Add link
				$resource->project = $project->id;
				$resource->user = $this->view->currentUser()->id;
				$resource->save();
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "resource";
				$feed->project = $resource->project;
				$feed->content = $resource->id;
				$feed->date = $resource->date;
				$feed->user = $resource->user;
				$feed->save();
				
				// Redirect
				$this->view->redirect("project", "resources", array('id'=>$project->link));
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->project = $project;
		$this->view->resource = $resource;
	}
	
	/**
	* Lists resources.
	* If the view variables "resources" isn't set it lists all the resources.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->resources))
			$this->view->resources = Models::getResources();
	}
}
