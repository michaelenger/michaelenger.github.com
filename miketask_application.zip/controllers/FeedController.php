<?php

/**
* FeedController
* Shows a feed of recent activity.
**/
class FeedController extends Zend_Controller_Action
{
	/**
	* Shows the feed.
	**/
	public function indexAction()
	{
		$this->view->enforceLogin();
		
		$this->view->feed = Models::getFeed($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"), 20);
		$this->view->rss = $this->view->url(array(), "rss", true);
	}
	
	/**
	* Shows all feed items.
	**/
	public function allAction()
	{
		$this->view->enforceLogin();
		
		$this->view->rss = $this->view->url(array(), "rss", true);
	}
	
	/**
	* Lists feed items.
	* Assumes that the view variable "feed" is set, if not uses the default feed.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		$sort = $this->getRequest()->getParam("sort");
		$order = $this->getRequest()->getParam("order");
		
		if(!is_array($this->view->feed)) $this->view->feed = Models::getFeed($sort, $order);
		
		// Pagination
		$pp = 50;
		$page = ($this->getRequest()->getParam("page") ? $this->getRequest()->getParam("page") : 1);
		$total = count($this->view->feed);
		
		$this->view->feed = array_slice($this->view->feed, ($page-1) * $pp, $pp);
		
		$this->view->sort = $sort;
		$this->view->order = $order;
		$this->view->pp = $pp;
		$this->view->page = $page;
		$this->view->total = $total;
		$this->view->rss = $this->view->url(array(), "rss", true);
	}
}
