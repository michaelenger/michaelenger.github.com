<?php

/**
* ProjectController
**/
class ProjectController extends Zend_Controller_Action
{
	/**
	* Default action.
	**/
	public function indexAction()
	{
		$this->view->enforceLogin();
		
		$this->view->projects = Models::getProjects();
		$this->view->headTitle("Projects", 'PREPEND');
	}
	
	/**
	* Create new project.
	**/
	public function addAction()
	{
		$this->view->enforceLogin();
		
		// Variables
		$errors = array();
		$project = new ProjectModel();
		
		// Add project
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			
			$project->fromArray($post, get_magic_quotes_gpc());
			
			if(empty($project->link))
			{
				$project->link = $this->view->urlize($project->name);
				$link = $project->link;
				$num = 2;
				while(Models::getProject($project->link))
				{
					$project->link = "{$link}-{$num}";
					$num++;
				}
			}
			
			$errors = $project->validate();
			
			if(!empty($_FILES['upload']['name']))
			{
				if($_FILES['upload']['error'] != 0) throw new Exception("[ProjectController::addAction] File upload error: {$_FILES['upload']['error']}");
				
				$filename = $project->id . "_" . date("U") .substr($_FILES['upload']['name'], strrpos($_FILES['upload']['name'],"."));
				
				if(!move_uploaded_file($_FILES['upload']['tmp_name'], "logo/{$filename}"))
					throw new Exception("[ProjectController::addAction] Unable to move uploaded file");
				else
				{
					if(!empty($project->logo))
						unlink("logo/{$project->logo}");
					$project->logo = $filename;
				}
			}
			
			if(empty($errors))
			{
				// Save project
				$project->creator = $this->view->currentUser()->id;
				$project->save();
				
				// Set logo to have the project's id
				if($project->logo)
				{
					$filename = $project->id . $project->logo;
					rename("logo/{$project->logo}", "logo/{$filename}");
					$project->logo = $filename;
					$project->save();
				}
				
				// Add current user
				$project->addUser($this->view->currentUser());
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "project";
				$feed->project = $project->id;
				$feed->date = $project->date_created;
				$feed->user = $project->creator;
				$feed->save();
				
				// Redirect
				$this->view->redirect("project", "view", array('id'=>$project->link));
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->project = $project;
	}
	
	/**
	* Administer the project.
	**/
	public function adminAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::adminAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::adminAction] No project found");
		
		if(!$project->hasMember($this->view->currentUser())) throw new Exception("[ProjectController::usersAction] You don't have access to this project");
		
		$errors = array();
		
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			
			// Edit project
			if(isset($post['edit_project']))
			{
				$project->fromArray($post, get_magic_quotes_gpc());
				
				$errors = $project->validate();
				
				if(!empty($_FILES['upload']['name']))
				{
					if($_FILES['upload']['error'] != 0) throw new Exception("[ProjectController::adminAction] File upload error: {$_FILES['upload']['error']}");
					
					$filename = $project->id . "_" . date("U") .substr($_FILES['upload']['name'], strrpos($_FILES['upload']['name'],"."));
					
					if(!move_uploaded_file($_FILES['upload']['tmp_name'], "logo/{$filename}"))
						throw new Exception("[ProjectController::adminAction] Unable to move uploaded file");
					else
					{
						if(!empty($project->logo))
							unlink("logo/{$project->logo}");
						$project->logo = $filename;
					}
				}
				
				// Ensure that the link would work as a URL
				$project->link = $this->view->urlize($project->link);
				
				// Check if link is already existing
				$other = Models::getProject($project->link);
				if($other && $other->id != $project->id)
					$errors['link'] = "A project with that link already exists";
				
				if(empty($errors))
				{
					$project->save();
					$this->view->redirect("project", "admin", array('id'=>$project->link)); // to ensure that a change in the link is effected
				}
			}
			
			// Archive project
			if(isset($post['archive_project']))
			{
				if(isset($post['agree']))
				{
					$project->archived = 1;
					$project->save();
				}
			}
			
			// Un-Archive project
			if(isset($post['unarchive_project']))
			{
				if(isset($post['agree']))
				{
					$project->archived = 0;
					$project->save();
				}
			}
			
			// Delete tasks
			if(isset($post['delete_tasks']))
			{
				unset($post['delete_tasks']);
				foreach($post as $key => $value)
					$project->removeTask($key);
			}
			
			// Delete resources
			if(isset($post['delete_resources']))
			{
				unset($post['delete_resources']);
				foreach($post as $key => $value)
					$project->removeResource($key);
			}
			
			// Leave the project
			if(isset($post['leave_project']))
			{
				if(isset($post['agree']))
				{
					if (count($project->getUsers()) == 1) throw new Exception("[ProjectController::adminAction] Unable to remove user from project");
					$project->removeUser($this->view->currentUser());
					$this->view->redirect("project", "view", array('id'=>$project->link));
				}
			}
			
			// Delete the project
			if(isset($post['delete_project']))
			{
				if($post['validate'] == "DELETE")
				{
					$project->delete();
					$this->view->redirect("projects");
				}
			}
		}
		
		// View variables
		$this->view->errors = $errors;
		$this->view->project = $project;
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Lists the feed items associated with a project.
	**/
	public function feedAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::tasksAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::tasksAction] No project found");
		
		$this->view->project = $project;
		$this->view->feed = $project->getFeed($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Shows a header.
	**/
	public function headerAction()
	{
		$this->view->current = Zend_Controller_Front::getInstance()->getRequest()->getActionName();
		$this->view->menu = array(
			'view' => "Overview",
			'feed' => "Feed",
			'tasks' => "Tasks",
			'members' => "Members",
			'resources' => "Resources",
			'timelog' => "Timelog",
			'summary' => "Summary"
		);
	}
	
	/**
	* Lists the projects.
	* If the view variables "projects" isn't set it lists all the projects.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->projects)) $this->view->projects = Models::getProjects();
		
		// Pagination
		$pp = 10;
		$page = ($this->getRequest()->getParam("page") ? $this->getRequest()->getParam("page") : 1);
		$total = count($this->view->projects);
		
		$this->view->projects = array_slice($this->view->projects, ($page-1) * $pp, $pp);
			
		$this->view->pp = $pp;
		$this->view->page = $page;
		$this->view->total = $total;
	}
	
	/**
	* Lists the users associated with this project.
	**/
	public function membersAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::membersAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::membersAction] No project found");
		
		$this->view->project = $project;
		$this->view->users = $project->getUsers();
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Lists the resources associated with this project.
	**/
	public function resourcesAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::resourcesAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::resourcesAction] No project found");
		
		$this->view->project = $project;
		$this->view->resources = $project->getResources();
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Shows a public summary of the project.
	**/
	public function summaryAction()
	{
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::resourcesAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::resourcesAction] No project found");
		
		$this->view->project = $project;
		$this->view->tasks = $project->getTasks('date_completed','ASC');
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Lists the tasks associated with a project.
	**/
	public function tasksAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::tasksAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::tasksAction] No project found");
		
		$this->view->project = $project;
		$this->view->tasks = $project->getTasks($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Shows the timelogs associated with the specified project.
	**/
	public function timelogAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::tasksAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::tasksAction] No project found");
		
		$type = ($this->getRequest()->getParam("type") ? $this->getRequest()->getParam("type") : "list");
		
		// View variables
		$this->view->project = $project;
		$this->view->timelog = $project->getTimelog($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"));
		$this->view->type = $type;
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
	
	/**
	* Add users to the project.
	**/
	public function usersAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::usersAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::usersAction] No project found");
		
		$error = "";
		
		if(!$project->hasMember($this->view->currentUser())) throw new Exception("[ProjectController::usersAction] You don't have access to this project");
		
		// Add user
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			if($post['user'] != 0)
				$project->addUser($post['user']);
		}
		
		// View variables
		$this->view->error = $error;
		$this->view->project = $project;
		$this->view->users = Models::getUsers();
	}
	
	/**
	* View a specific project.
	**/
	public function viewAction()
	{
		$this->view->enforceLogin();
		
		if(!$this->getRequest()->getParam("id"))
			throw new Exception("[ProjectController::viewAction] Missing parameter: id");
		$project = Models::getProject($this->getRequest()->getParam("id"));
		if(!$project) throw new Exception("[ProjectController::viewAction] No project found");
		
		$this->view->project = $project;
		$this->view->comments = $project->getComments();
		$this->view->feed = $project->getFeed($this->getRequest()->getParam("sort"), $this->getRequest()->getParam("order"), 5);
		$this->view->rss = $this->view->url(array('action'=>"project",'id'=>$project->id), "rss", true);
		$this->view->headTitle($project->name, 'PREPEND');
	}
}
