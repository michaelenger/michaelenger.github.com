<?php

/**
* TimelogController
* Shows timelogs.
**/
class TimelogController extends Zend_Controller_Action
{
    /**
	* Deletes the timelog.
	**/
	public function deleteAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->enforceLogin();
		if(!$this->getRequest()->getParam("id")) throw new Exception("[TimelogController::deleteAction] Missing parameter: id");
		
		$timelog = Models::getTimelog($this->getRequest()->getParam("id"));
		if ($this->view->currentUser()->id != $timelog['user']) throw new Exception("[TimelogController::deleteAction] Invalid user: " . $this->view->currentUser()->id . " != " . $timelog['user']);
		
		Models::removeTimelog($timelog['id']);
		
		// Redirect
		if(!$this->getRequest()->isXmlHttpRequest())
			$this->view->redirect("task", "view", array('id'=>$timelog['task']), "#timelog");
		else
			die(); // Prevent any loading
	}
	
	/**
	* Default action; list timelogs.
	* Assumes that the view variable "timelog" is set.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->timelog)) throw new Exception("[TimelogController::listAction] Variable not set: timelog");
		$this->view->sort = $this->getRequest()->getParam("sort");
		$this->view->order = $this->getRequest()->getParam("order");
	}
	
	/**
	* Shows a graph of the timelog.
	* Assumes that the view variables "timelog" and "sections" are set.
	**/
	public function graphAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->timelog)) throw new Exception("[TimelogController::graphAction] Variable not set: timelog");
		if(!is_array($this->view->sections)) throw new Exception("[TimelogController::graphAction] Variable not set: sections");
		
		$timelog = $this->view->timelog;
		$max = 0;
		
		if(!empty($timelog))
		{
			$max = ceil(max($timelog));
			while($max % 24 != 0)
				$max++;
		}
		
		$this->view->max = $max;
	}
	
	/**
	* Shows a graph of the timelog for a monthly amount.
	* Assumes that the view variable "timelog" is set.
	**/
	public function monthAction()
	{
		$this->view->enforceLogin();
		
		$year = date("Y");
		if($this->getRequest()->getParam("year")) $year = $this->getRequest()->getParam("year");
		$month = date("n");
		if($this->getRequest()->getParam("month")) $month = $this->getRequest()->getParam("month");
		
		if(!is_array($this->view->timelog)) throw new Exception("[TimelogController::monthAction] Variable not set: timelog");
		
		// Splits the timelog into months
		$timelog = array();
		
		foreach($this->view->timelog as $i => $log)
		{
			$tyear = date("Y", strtotime($log['date']));
			$tmonth = date("n", strtotime($log['date']));
			$tday = date("j", strtotime($log['date']));
			
			// Ignore entries that dont pertain to the current year/month
			if($tyear != $year || $tmonth != $month) continue;
			
			if(!array_key_exists($tday, $timelog)) $timelog[$tday] = 0;
			$timelog[$tday] += $log['amount'];
		}
		
		// Build sections
		$sections = array();
		for($i = 1; $i <= date("t", mktime(0,0,0,$month)); $i++)
			$sections[$i] = $i;
		
		$this->view->sections = $sections;
		$this->view->timelog = $timelog;
		$this->view->month = $month;
		$this->view->year = $year;
	}
	
	/**
	* Shows a graph of the timelog for projects.
	* Assumes that the view variables "timelog" and "projects" are set.
	**/
	public function projectAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->timelog)) throw new Exception("[TimelogController::projectAction] Variable not set: timelog");
		if(!is_array($this->view->projects)) throw new Exception("[TimelogController::projectAction] Variable not set: projects");
		
		// Splits the timelog per project
		$timelog = array();
		$projects = $this->view->projects;
		
		foreach($this->view->timelog as $i => $log)
		{
			$task = new TaskModel($log['task']);
			
			// Ignore entries that dont pertain to the projects
			if(!array_key_exists($task->project, $projects)) continue;
			
			if(!array_key_exists($task->project, $timelog)) $timelog[$task->project] = 0;
			$timelog[$task->project] += $log['amount'];
		}
		
		// Build sections
		$sections = array();
		foreach($projects as $project)
			$sections[$project->id] = '<a href="'.$this->view->url(array('id'=>$project->getLink()),"project",true).'">'.htmlspecialchars($project->name).'</a>';
		
		$this->view->sections = $sections;
		$this->view->timelog = $timelog;
	}
	
	/**
	* Shows a graph of the timelog for users.
	* Assumes that the view variables "timelog" and "users" are set.
	**/
	public function userAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->timelog)) throw new Exception("[TimelogController::userAction] Variable not set: timelog");
		if(!is_array($this->view->users)) throw new Exception("[TimelogController::userAction] Variable not set: users");
		
		// Splits the timelog per project
		$timelog = array();
		$users = $this->view->users;
		
		foreach($this->view->timelog as $i => $log)
		{			
			// Ignore entries that dont pertain to the projects
			if(!array_key_exists($log['user'], $users)) continue;
			
			if(!array_key_exists($log['user'], $timelog)) $timelog[$log['user']] = 0;
			$timelog[$log['user']] += $log['amount'];
		}
		
		// Build sections
		$sections = array();
		foreach($users as $user)
			$sections[$user->id] = '<a href="'.$this->view->url(array('id'=>$user->id),"project",true).'">'.htmlspecialchars($user->name).'</a>';
		
		$this->view->sections = $sections;
		$this->view->timelog = $timelog;
	}
	
	/**
	* Shows a graph of the timelog for a yearly amount.
	* Assumes that the view variable "timelog" is set.
	**/
	public function yearAction()
	{
		$this->view->enforceLogin();
		
		$year = date("Y");
		if($this->getRequest()->getParam("year")) $year = $this->getRequest()->getParam("year");
		
		if(!is_array($this->view->timelog)) throw new Exception("[TimelogController::yearAction] Variable not set: timelog");
		
		// Splits the timelog into months
		$timelog = array();
		
		foreach($this->view->timelog as $i => $log)
		{
			$tyear = date("Y", strtotime($log['date']));
			$tmonth = date("n", strtotime($log['date']));
			
			// Ignore entries that dont pertain to the current year
			if($tyear != $year) continue;
			
			if(!array_key_exists($tmonth, $timelog)) $timelog[$tmonth] = 0;
			$timelog[$tmonth] += $log['amount'];
		}
		
		
		// Build sections
		$sections = array();
		for($i = 1; $i <= 12; $i++)
			$sections[$i] = date("M", mktime(0,0,0,$i));
		
		$this->view->sections = $sections;
		$this->view->timelog = $timelog;
		$this->view->year = $year;
	}
}
