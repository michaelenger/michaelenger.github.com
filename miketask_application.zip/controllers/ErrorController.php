<?php

/**
* ErrorController
* Invoked whenever an error occurs in the script.
**/
class ErrorController extends Zend_Controller_Action
{
	/**
	* Handles errors.
	**/
	public function errorAction()
	{
		// Ensure that we always return good content
		$this->_helper->viewRenderer->setViewSuffix("phtml");
		
		// Grab error object from the request
		$errors = $this->_getParam("error_handler");
		
		switch ($errors->type)
		{
			case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_CONTROLLER:
			case Zend_Controller_Plugin_ErrorHandler::EXCEPTION_NO_ACTION:
				// 404
				$this->getResponse()->setHttpResponseCode(404);
				$this->view->title = "Page Not Found";
				break;
				
			default:
				// Application error
				$this->getResponse()->setHttpResponseCode(500);
				$this->view->title = "Error";
				$this->view->message = $errors->exception->getMessage();
				break;
		}
		
		$this->view->headTitle($this->view->title, 'PREPEND');
		$this->view->env = APPLICATION_ENVIRONMENT;
		$this->view->exception = $errors->exception;
		$this->view->request = $errors->request;
	}
}
