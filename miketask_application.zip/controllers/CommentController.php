<?php

/**
* CommentController
**/
class CommentController extends Zend_Controller_Action
{
	/**
	* Default action.
	**/
	public function indexAction()
	{
		throw new Exception("[CommentController::indexAction] Action not implemented");
	}
	
	/**
	* Add a new comment.
	**/
	public function addAction()
	{
		$this->view->enforceLogin();
		
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$comment = new CommentModel();
		$errors = array();
		
		if($this->getRequest()->getParam("type"))
			$comment->type = $this->getRequest()->getParam("type");
		if($this->getRequest()->getParam("parent"))
			$comment->parent = $this->getRequest()->getParam("parent");
		
		// Add comment
		if($this->getRequest()->isPost())
		{
			$post = $this->getRequest()->getPost();
			
			$comment->fromArray($post, get_magic_quotes_gpc());
			
			$errors = $comment->validate();
			
			if(empty($errors))
			{
				// Add comment
				$comment->user = $this->view->currentUser()->id;
				$comment->save();
				
				// Create feed item
				$feed = new FeedModel();
				$feed->type = "comment";
				if($comment->type == "project")
					$feed->project = $comment->parent;
				if($comment->type == "task")
				{
					$task = new TaskModel($comment->parent);
					$feed->project = $task->project;
					$feed->task = $task->id;
				}
				$feed->content = $comment->id;
				$feed->date = $comment->date;
				$feed->user = $comment->user;
				$feed->save();
				
				// Redirect
				if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
				{
					$this->view->comment = $comment;
					$this->view->user = $this->view->currentUser();
					$this->render("view");
				}
				else
					header("Location: " . $comment->getLink());
			}
		}
		
		// View variables
		$this->view->comment = $comment;
		$this->view->errors = $errors;
	}
	
	/**
	* Lists the comments.
	* If the view variables "comments" isn't set it lists all the comments.
	**/
	public function listAction()
	{
		$this->view->enforceLogin();
		
		if(!is_array($this->view->comments))
			$this->view->comments = Models::getComments();
	}
	
	/**
	* View a specific comment.
	* Assumes that the view variable "comment" is set.
	**/
	public function viewAction()
	{
		$this->view->enforceLogin();
		
		if(!is_object($this->view->comment)) throw new Exception("[CommentController::viewAction] Variable not set: comment");
		$this->view->user = new UserModel($this->view->comment->user);
	}
}
