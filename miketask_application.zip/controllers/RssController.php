<?php

/**
* RSSController
* Shows an rss feed of recent activity.
**/
class RSSController extends Zend_Controller_Action
{
	/**
	* Default action; shows all feed items.
	**/
	public function allAction()
	{
		$limit = 20;
		if($this->getRequest()->getParam("limit")) $limit = $this->getRequest()->getParam("limit");

		$this->view->layout()->setLayout("rss");
		$this->view->feed = Models::getFeed(null, null, $limit);
		$this->view->headTitle("RSS Feed", 'PREPEND');
		$this->render("default");
	}

	/**
	* Shows feed items for a specific project.
	**/
	public function projectAction()
	{
		if(!$this->getRequest()->getParam("id")) throw new Exception("[RSSController::projectAction] Missing parameter: id");

		$limit = 20;
		if($this->getRequest()->getParam("limit")) $limit = $this->getRequest()->getParam("limit");

		$project = new ProjectModel($this->getRequest()->getParam("id"));

		$this->view->layout()->setLayout("rss");
		$this->view->feed = $project->getFeed(null, null, $limit);
		$this->view->headTitle("RSS Feed for {$project->name}", 'PREPEND');
		$this->render("default");
	}

	/**
	* Shows feed items for a specific user.
	**/
	public function userAction()
	{
		if(!$this->getRequest()->getParam("id")) throw new Exception("[RSSController::userAction] Missing parameter: id");
		
		$limit = 20;
		if($this->getRequest()->getParam("limit")) $limit = $this->getRequest()->getParam("limit");

		$user = new UserModel($this->getRequest()->getParam("id"));

		$this->view->layout()->setLayout("rss");
		$this->view->feed = $user->getFeed(null, null, $limit);
		$this->view->headTitle("RSS Feed for {$user->name}", 'PREPEND');
		$this->render("default");
	}
}
