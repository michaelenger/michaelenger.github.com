<?php

/**
* UtilitiesController
* Holds AJAX utilities
**/
class UtilitiesController extends Zend_Controller_Action
{
	/**
	* Shows a datepicker.
	**/
	public function calendarAction()
	{
		if($this->getRequest()->isXmlHttpRequest()) // AJAX'd
			$this->view->layout()->setLayout("empty");
		
		$this->view->year = ($this->getRequest()->getParam("year") ? $this->getRequest()->getParam("year") : date("Y"));
		$this->view->month = ($this->getRequest()->getParam("month") ? $this->getRequest()->getParam("month") : date("n"));
		$this->view->day = ($this->getRequest()->getParam("day") ? $this->getRequest()->getParam("day") : date("j"));
	}
}
